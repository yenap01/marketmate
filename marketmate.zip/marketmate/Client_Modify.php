<?php
//   $id = $_GET["id"];
	$id = $_POST["id"];

    $passwd = $_POST["passwd"];
    $name = $_POST["name"];
    $email1  = $_POST["email1"];
    $email2  = $_POST["email2"];
    $tel = $_POST["tel"];

    $email = $email1."@".$email2;
          
    $con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");
    $sql = "update client set passwd='$passwd', name='$name', email='$email', tel='$tel'";
    $sql .= " where id='$id'";
    mysqli_query($con, $sql);

    mysqli_close($con);     

    echo "
	      <script>
	          location.href = 'index.html';
	      </script>
	  ";
?>

   
