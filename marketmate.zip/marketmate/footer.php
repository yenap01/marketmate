<!DOCTYPE html>
<html>
<head> 
	<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/53a8c415f1.js" crossorigin="anonymous"></script>
	<link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid bg-dark text-light footer mt-5 pt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">주소지</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>서울특별시 종로구 사직로</p><p>&nbsp &nbsp (적선동 81-1)</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+031 - 1234 - 5678</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>12345@baewha.ac.kr</p>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">서비스</h4>
                    <a class="btn btn-link" href="history.html">결제내역</a>
                    <a class="btn btn-link" href="heart.html">나의찜</a>
                    <a class="btn btn-link" href="Recently.html">최근본상품</a>
                    <a class="btn btn-link" href="information.html">정보관리</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">빠르게 보러가기</h4>
                    <a class="btn btn-link" href="category.html">카테고리</a>
                    <a class="btn btn-link" href="sale.html">세일</a>
                    <a class="btn btn-link" href="event.html">이벤트</a>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="#">MarketMate</a>, All Right Reserved.
                    </div>>
                </div>
            </div>
        </div>
    </div>
	</body>
</html>