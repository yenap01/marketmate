<?php
    $id   	 = $_POST["id"];
    $passwd  = $_POST["passwd"];
    $name 	 = $_POST["name"];
    $email1  = $_POST["email1"];
    $email2  = $_POST["email2"];
	$tel 	 = $_POST["tel"];

    $email 	 = $email1."@".$email2;
	$regist_day = date("Y-m-d (H:i)");
	
	echo "id => $id<br>";
	echo "passwd => $passwd<br>";
	echo "name => $name<br>";
	echo "email1 => $email1<br>";
    echo "email2 => $email2<br>";
	echo "tel => $tel<br>";
	echo "regist_day => $regist_day<br>";
             
    $con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");

	$sql = "insert into client(id, passwd, name, email, tel, regist_day, level) ";
	$sql .= "values('$id', '$passwd', '$name', '$email', '$tel', '$regist_day', 9)";
	
	echo $sql;

	mysqli_query($con, $sql);  // $sql 에 저장된 명령 실행
    mysqli_close($con);     

    echo "
	      <script>
	          location.href = 'index.html';
	      </script>
	  ";
?>


