<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>MarketMate</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500&family=Roboto:wght@500;700;900&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="./css/common.css">
    <link rel="stylesheet" type="text/css" href="./css/board.css">
</head>
<body>
    <!--header.php 불러오기-->
    <header>
        <?php
               session_start();
               if (isset($_SESSION["id"])) $id = $_SESSION["id"];
               else $id = "";
               $logged = $id;
        ?>
        <?php include "header.php";?>
    </header>

    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">문의하기</h1>
        </div>
    </div>
    <!-- Page Header End -->

   	<div id="board_box">
	    <h3>
	    	문의 내역
		</h3>
    <?php
    	$num  = $_GET["num"];
    	$page  = $_GET["page"];

    	$con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");
    	$sql = "select * from enquire where num=$num";
    	$result = mysqli_query($con, $sql);

    	$row = mysqli_fetch_array($result);
    	$id         = $row["id"];
    	$regist_day = $row["regist_day"];
    	$subject    = $row["subject"];
    	$content    = $row["content"];
    	$hit        = $row["hit"];

    	$content = str_replace(" ", "&nbsp;", $content);
    	$content = str_replace("\n", "<br>", $content);

    	$new_hit = $hit + 1;
    	$sql = "update enquire set hit=$new_hit where num=$num";
    	mysqli_query($con, $sql);
    ?>
    	    <ul id="view_content">
    			<li>
    				<span class="col1"><b>제목 :</b> <?=$subject?></span>
    				<span class="col2"><?=$id?> | <?=$regist_day?></span>
    			</li>
    			<li>
    				<?=$content?>
    			</li>
    	    </ul>
	    <ul class="buttons">
				<li><button onclick="location.href='contact_list.php?page=<?=$page?>'">목록</button></li>
				<li><button onclick="location.href='contact_modify_form.php?num=<?=$num?>&page=<?=$page?>'">수정</button></li>
				<li><button onclick="location.href='contact_delete.php?num=<?=$num?>&page=<?=$page?>'">삭제</button></li>
				<li><button onclick="location.href='contact.php'">글쓰기</button></li>
		</ul>
	</div>
</body>

</html>