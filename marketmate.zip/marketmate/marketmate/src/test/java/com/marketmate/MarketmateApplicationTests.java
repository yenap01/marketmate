package com.marketmate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketmateApplicationTests {

	@Test
	void contextLoads() {
	}

}
