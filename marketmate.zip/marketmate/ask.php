<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,intial-scale=1,maximum-scale=1">
        <title>MarketMate ADMIN</title>
        <link rel="stylesheet" type="text/css" href="./css/common.css">
        <link rel="stylesheet" type="text/css" href="./css/admin.css">
        <link rel="stylesheet" href="Admin_style.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    </head>
    <body>
        <input type="checkbox" id="nav-toggle">
        <div class="sidebar">
            <div class="sidebar-brand">
                <h1><span class="fa-solid fa-bowl-food"></span><span>MarketMate</span></h1>
            </div>
            <div class="sidebar-menu">
                <ul>
                    <li>
                        <a href="customer_information.php"><span class="las la-users"></span><span>고객정보</span></a>
                    </li>
                    <li>
                        <a href="product_manage.php"><span class="las la-clipboard-list"></span><span>상품 관리</span></a>
                    </li>
                    <li>
                        <a href="product_register.php"><span class="las la-shopping-bag"></span><span>상품 등록 </span></a>
                    </li>
                    <li>
                        <a href="order_list.php"><span class="las la-clipboard-list"></span><span>주문 리스트</span></a>
                    </li>
                    <li>
                        <a href="ask.php" class="active"><span class="las la-receipt"></span>
                            <span>1:1 문의</span></a>
                    </li>
               <br> <br> <br> <br> <br> <br> <br> <br>
            <?php
               session_start();
               if (isset($_SESSION["id"])) $id = $_SESSION["id"];
               else $id = "";
               if (isset($_SESSION["name"])) $name = $_SESSION["name"];
               else $name = "";
               $logged = $name."(".$id.")";
            ?>
            <div id="logout_form">
               <form  name="logout_form" method="post" action="logout.php">
               <a href="logout.php"> &nbsp &nbsp &nbsp &nbsp <?=$logged?> &nbsp 로그아웃 </a>
            </div>
            </ul>
         </div>
        </div>

        <div class="main-content">
            <header>
                <h2>
                    <label for="nav-toggle">
                        <span class="las la-bars"></span>
                    </label>
                    1:1 문의
                </h2>
            </header>
            <main>
                <div class="recent-grid">
                    <div class="projects">
                        <div class="card">
                            <div class="card-header">
                                <h3>관리자&nbsp&nbsp/&nbsp&nbsp1:1 문의</h3>
                            </div>
                                <ul id="board_list">
									 <li>
										<span class="col1">선택</span>
										<span class="col2">번호</span>
										<span class="col3">작성자</span>
										<span class="col4"> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 제목</span>
										<span class="col5">등록일</span>
										<span class="col6">조회</span>
									 </li>
                                      <?php
                                         $con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");
                                         $sql = "select * from enquire order by num";
                                         $result = mysqli_query($con, $sql);
                                         $total_record = mysqli_num_rows($result); // 전체 회원 수

                                         $number = $total_record;

                                         while ($row = mysqli_fetch_array($result))
                                         {
                                           $num         = $row["num"];
                                           $subject     = $row["subject"];
                                           $id          = $row["id"];
                                           $regist_day  = $row["regist_day"];
                                           $hit         = $row["hit"];
                                      ?>
                                                <li>
                                                    <span class="col1"><input type="checkbox" name="item[]" value="<?=$num?>"></span>
                                                    <span class="col2"><?=$number?></a></span>
                                                    <span class="col3"><?=$id?></span>
                                                    <span class="col4"><?=$subject?></span>
                                                    <span class="col5"><?=$regist_day?></span>
                                                    <span class="col6"><?=$hit?></span>
                                                </li>
									<?php
										   $number--;
									   }
									?>
								</ul>
	                    </div>
					</div>
                </div>
            </main>
        </div>
    </body>
</html>