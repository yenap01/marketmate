   function check_input()
   {
        const id = document.querySelector("form[name=ClientForm] input[name=id]")
        const passwd = document.querySelector("form[name=ClientForm] input[name=passwd]")
        const passwd_confirm = document.querySelector("form[name=ClientForm] input[name=passwd_confirm]")
        const name = document.querySelector("form[name=ClientForm] input[name=name]")
        const email1 = document.querySelector("form[name=ClientForm] input[name=email1]")
		const email2 = document.querySelector("form[name=ClientForm] input[name=email2]")
        const tel = document.querySelector("form[name=ClientForm] input[name=tel]")

       if (!id.value)
       {
           alert("아이디를 입력해주세요.");
           id.focus();
           return;
       }

      if (!passwd.value)
      {
          alert("비밀번호를 입력해주세요.");    
          passwd.focus();
          return;
      }

      if (!passwd_confirm.value)
      {
          alert("비밀번호확인을 입력해주세요.");    
          passwd_confirm.focus();
          return;
      }

      if (!name.value)
      {
          alert("이름을 입력해주세요.");    
          name.focus();
          return;
      }

      if (!email1.value)
      {
          alert("이메일을 입력해주세요.");    
          email1.focus();
          return;
      }
	  
	  if (!email2.value)
      {
          alert("이메일을 입력해주세요.");    
          email2.focus();
          return;
      }

      if (!tel.value)
      {
          alert("휴대폰 번호를 입력해주세요.");    
          tel.focus();
          return;
      }

      if (passwd.value != passwd_confirm.value)
      {
          alert("비밀번호가 일치하지 않습니다.\n다시 입력해 주세요!");
          passwd.focus();
          passwd.select();
          return;
      }

      document.querySelector("form[name=ClientForm]").submit();
   }

   function reset_form()
   {
      document.ClientForm.id.value = "";  
      document.ClientForm.passwd.value = "";
      document.ClientForm.passwd_confirm.value = "";
      document.ClientForm.name.value = "";
      document.ClientForm.email1.value = "";
      document.ClientForm.email2.value = "";
      document.ClientForm.tel.value = "";
	  
      document.ClientForm.id.focus();

      return;
   }