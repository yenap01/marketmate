var mysql = require('mysql2');
var db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'skqkrl01',
    database: 'logintest'
});
db.connect();

module.exports = db;