<?php
    $id   = $_POST["id"];
    $passwd = $_POST["passwd"];

   $con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");

   $sql = "select * from client where id='$id' and passwd ='$passwd'";
   echo "[".$sql."]";
   
   $result = mysqli_query($con, $sql);

   $num_match = mysqli_num_rows($result);
//   echo "[".$num_match."]";

    if(!$num_match) 
    {
        echo("
            <script>
             window.alert('등록되지 않은 아이디입니다!')
             history.go(-1)
            </script>
        ");
    }
    else
    {
        $row = mysqli_fetch_array($result);
        $db_passwd = $row["passwd"];

        mysqli_close($con);
		
		session_start();
        $_SESSION["id"] = $row["id"];
        $_SESSION["name"] = $row["name"];

        echo("
            <script>
            location.href = 'index.html';
            </script>
        ");
	}

    if($passwd != $db_passwd)
    {
        echo("
              <script>
                window.alert('비밀번호가 틀립니다!')
                history.go(-1)
              </script>
            ");
        exit;
    }
    else
    {
        session_start();
        $_SESSION["id"] = $row["id"];
        $_SESSION["name"] = $row["name"];

        echo("
              <script>
                location.href = 'index.html';
              </script>
            ");
    }

	
	if ($row["level"] == 1) {
    
		header("Location: customer_information.php");
		exit;
	} else {
    echo "로그인 실패. 다시 시도하세요.";
	}

?>