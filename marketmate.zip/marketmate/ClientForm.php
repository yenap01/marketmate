<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>회원가입</title>

<link href="css/style.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="./css/common.css">
<link rel="stylesheet" type="text/css" href="./css/member.css">
<script>
   function check_input()
   {
      if (!document.ClientForm.id.value) {
          alert("아이디를 입력해주세요.");    
          document.ClientForm.id.focus();
          return;
      }

      if (!document.ClientForm.passwd.value) {
          alert("비밀번호를 입력해주세요.");    
          document.ClientForm.passwd.focus();
          return;
      }

      if (!document.ClientForm.passwd_confirm.value) {
          alert("비밀번호 확인을 입력해주세요.");    
          document.ClientForm.passwd_confirm.focus();
          return;
      }

      if (!document.ClientForm.name.value) {
          alert("이름을 입력해주세요.");    
          document.ClientForm.name.focus();
          return;
      }

      if (!document.ClientForm.email1.value) {
          alert("이메일을 입력해주세요.");    
          document.ClientForm.email1.focus();
          return;
      }  	 
	
	if (!document.ClientForm.email2.value) {
          alert("이메일을 입력해주세요.");    
          document.ClientForm.email2.focus();
          return;
      } 	  
	  
	  if (!document.ClientForm.tel.value) {
          alert("휴대폰 번호를 입력해주세요.");    
          document.ClientForm.tel.focus();
          return;
      }

      if (document.ClientForm.passwd.value != 
            document.ClientForm.passwd_confirm.value) {
          alert("비밀번호가 일치하지 않습니다.\n다시 입력해 주세요");
          document.ClientForm.passwd.focus();
          document.ClientForm.passwd.select();
          return;
      }
	  
	  if (!document.querySelector('.agree').checked) {
          alert("이용약관에 동의해야 회원가입이 가능합니다.");
          return;
      }

      document.ClientForm.submit();
   }

   function reset_form() {
      document.ClientForm.id.value = "";  
      document.ClientForm.passwd.value = "";
      document.ClientForm.passwd_confirm.value = "";
      document.ClientForm.name.value = "";
      document.ClientForm.email1.value = "";
	  document.ClientForm.email2.value = "";
	  document.ClientForm.tel.value = "";
      document.ClientForm.id.focus();
      return;
   }

   function check_id() {
     window.open("ClientCheck_id.php?id=" + document.ClientForm.id.value,
        "IDcheck",
        "left=700,top=300,width=350,height=200,scrollbars=no,resizable=yes");
   }
</script>
</head>
<body> 
	<header>
		<a href="index.html"><img src="./img/logo.png"></a>
    </header>
	<section>
        <div id="main_content">
      		<div id="join_box">
          	<form  name="ClientForm" method="post" action="ClientInsert.php">
			    <h2>회원 가입</h2>
    		    	<div class="form id">
				        <div class="col1">아이디</div>
				        <div class="col2">
							<input type="text" name="id">
				        </div>  
				        <div class="col3">
				        	<a href="#"><img src="./img/check_id.gif" 
				        		onclick="check_id()"></a>
				        </div>                 
			       	</div>
			       	<div class="clear"></div>

			       	<div class="form">
				        <div class="col1">비밀번호</div>
				        <div class="col2">
							<input type="password" name="passwd">
				        </div>                 
			       	</div>
			       	<div class="clear"></div>
			       	<div class="form">
				        <div class="col1">비밀번호 확인</div>
				        <div class="col2">
							<input type="password" name="passwd_confirm">
				        </div>                 
			       	</div>
			       	<div class="clear"></div>
			       	<div class="form">
				        <div class="col1">이름</div>
				        <div class="col2">
							<input type="text" name="name">
				        </div>                 
			       	</div>
					<div class="clear"></div>
			       	<div class="form email">
				        <div class="col1">이메일</div>
				        <div class="col2">
							<input type="text" name="email1">@<input type="text" name="email2">
				        </div>                 
			       	</div>		
			       	<div class="clear"></div>
			       	<div class="form">
				        <div class="col1">휴대폰 번호</div>
				        <div class="col2">
							<input type="text" name="tel">
				        </div>                 
			       	</div>					
			       	<div class="clear"></div>
					<br>
					<input type="checkbox" class="agree" id="agreeCheckbox">&nbsp 이용약관 개인정보 수집 및 정보이용에 동의합니다.	
					<br>
			       	<div class="bottom_line"> </div>
			       	<div class="buttons">
	                	<img style="cursor:pointer" src="./img/button_save.gif" onclick="check_input()">&nbsp;
                  		<img id="reset_button" style="cursor:pointer" src="./img/button_reset.gif"
                  			onclick="reset_form()">
	           		</div>
           	</form>
        	</div> <!-- join_box -->
        </div> <!-- main_content -->
	</section> 
	<footer>
    	<?php include "footer.php";?>
    </footer>
</body>
</html>

