<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,intial-scale=1,maximum-scale=1">
        <title>MarketMate ADMIN</title>
        <link rel="stylesheet" type="text/css" href="./css/common.css">
        <link rel="stylesheet" type="text/css" href="./css/admin.css">
        <link rel="stylesheet" href="Admin_style.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <script>
	  function check_input() {
		  if (!document.product_register.Item_Id.value)
		  {
			  alert("상품코드를 입력하세요.");
			  document.product_register.Item_Id.focus();
			  return;
		  }
		  if (!document.product_register.Item_Type.value)
		  {
			  alert("종류를 입력하세요.");
			  document.product_register.Item_Type.focus();
			  return;
		  }
		  if (!document.product_register.Item_Name.value)
		  {
			  alert("상품명을 입력하세요.");
			  document.product_register.Item_Name.focus();
			  return;
		  }
		  if (!document.product_register.Item_Price.value)
		  {
			  alert("가격을 입력하세요.");
			  document.product_register.Item_Price.focus();
			  return;
		  }
		  if (!document.product_register.Item_Stock.value)
		  {
			  alert("재고를 입력하세요.");
			  document.product_register.Item_Stock.focus();
			  return;
		  }
		  if (!document.product_register.content.value)
		  {
			  alert("상세설명란을 입력하세요.");    
			  document.product_register.php.content.focus();
			  return;
		  }
		  document.product_register.submit();
	   }
	</script>
	
	</head>
    <body>
        <input type="checkbox" id="nav-toggle">
        <div class="sidebar">
            <div class="sidebar-brand">
                <h1><span class="fa-solid fa-bowl-food"></span><span>MarketMate</span></h1>
            </div>
            <div class="sidebar-menu">
                <ul>
                    <li>
                        <a href="customer_information.php"><span class="las la-users"></span><span>고객정보</span></a>
                    </li>
                    <li>
                        <a href="product_manage.php"><span class="las la-clipboard-list"></span><span>상품 관리</span></a>
                    </li>
                    <li>
                        <a href="product_register.php" class="active"><span class="las la-shopping-bag"></span><span>상품 등록 </span></a>
                    </li>
                    <li>
                        <a href="order_list.php"><span class="las la-clipboard-list"></span><span>주문 리스트</span></a>
                    </li>
                    <li>
                        <a href="ask.php"><span class="las la-receipt"></span>
                            <span>1:1 문의</span></a>
                    </li>
                   <br> <br> <br> <br> <br> <br> <br> <br>
                <?php
                   session_start();
                   if (isset($_SESSION["id"])) $id = $_SESSION["id"];
                   else $id = "";
                   if (isset($_SESSION["name"])) $name = $_SESSION["name"];
                   else $name = "";
                   $logged = $name."(".$id.")";
                ?>
                <div id="logout_form">
                   <form  name="logout_form" method="post" action="logout.php">
                   <a href="logout.php"> &nbsp &nbsp &nbsp &nbsp <?=$logged?> &nbsp 로그아웃 </a>
                </div>
                </ul>
             </div>
        </div>
        <div class="main-content">
            <header>
                <h2>
                    <label for="nav-toggle">
                        <span class="las la-bars"></span>
                    </label>
                    상품 등록
                </h2>
                <div class="search-wrapper">
                    <span class="las la-search"></span>
                    <input type="search" placeholder="Search here"/>
                </div>
            </header>
            <main>
                <div class="recent-grid">
                    <div class="projects">
                        <div class="card">
                            <div class="card-header">
                                <h3>상품 등록</h3>
                                <button type="button" onclick="check_input()">등록하기<span class="las la-aroow-right"></span></button>
                            </div>
							<div class="card-body">
                                <div class="table-responsive">
                                    <table width="100%">
                                        <div class="container">
                                            <form name="newProduct" method="post" action="ProductInsert.php" enctype="multipart/form-data">
										<li>
											<span class="col1">종류</span> <br>
											<div class="col-sm-5">
												<div class="col-sm-3"> &nbsp 
													<input type="radio" name="category" value="food" onclick="toggleCategory('foodCategory')"> 신선식품 / 가공식품  &nbsp &nbsp
													<input type="radio" name="category" value="daily" onclick="toggleCategory('drinkCategory')"> 생활용품
												 </div>
                                            </div>
												<div class="form-group row" id="foodCategory" style="display:none;">
                                                    <label class="col-sm-2">신선식품 / 가공식품</label>
                                                    <div class="col-sm-5">
                                                        <div class="col-sm-3">
                                                                <select size="1" name="foodKind">
                                                                    <option value="">과일,채소</option>
                                                                    <option value="">아이스크림,얼음</option>
                                                                    <option value="">정육,계란</option>
                                                                    <option value= "">면,통조림</option>
                                                                    <option value= "">유제품</option>
                                                                    <option value= "">쌀,잡곡</option>
                                                                    <option value= "">냉장,냉동</option>
                                                                    <option value= "">수산물,건어물</option>
                                                                    <option value= "">김치,반찬</option>
                                                                    <option value= "">과자,시리얼</option>
                                                                    <option value= "">커피,차</option>
                                                                    <option value= "">장류,양념</option>
                                                                    <option value= "">주류,음료</option>
                                                                </select>
															</div>
														</div>
													</div>
													<div class="form-group row" id="dailyCategory" style="display:none;">
														<label class="col-sm-2">생활용품</label>
														<div class="col-sm-5">
															<div class="col-sm-3">
																<select size="1" name="drinkKind">
																	<option value="">세탁,청소,욕실</option>
																	<option value="">주방용품</option>
																	<option value="">위생,뷰티</option>
																	<option value="">리빙,인테리어</option>
																	<option value="">건강식품</option>
																	<option value="">문구용품</option>
																	<option value="">유아동,완구</option>
																	<option value="">반려동물</option>
																</select>
															</div>
														</div>
													</div>
												</div>
										</li>
										<br>
										<li>
											<span class="col1">상품코드</span> <br>
											<span class="col2"><input type="text" name="Item_Id"></span>
										</li>	
										<br>
										<li>	
											<span class="col1">상품명</span> <br>
											<span class="col2"><input type="text" name="Item_Name"></span>
										</li>
										<br>
										<li>
											<span class="col1">가격</span> <br>
											<span class="col2"><input type="text" name="Item_Price"></span>
										</li>
										<br>
										<li>
											<span class="col1">재고</span> <br>
											<span class="col2"><input type="text" name="Item_Stock"></span>
										</li>
										<br>
										<li>
											<span class="col1">첨부 파일</span>  &nbsp
											<span class="col2"><input type="file" name="upfile"></span>
										</li>
										<br>
										<li id="text_area">	
											<span class="col1">상품 상세 설명</span>
											<br>
											<span class="col2">
												<textarea name="content"></textarea>
											</span>
										</li>
							</form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </body>
</html>