<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>MarketMate</title>
<link href="css/style.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="./css/common.css">
<link rel="stylesheet" type="text/css" href="./css/main.css">
</head>
<body> 
	<header>
    	<?php include "header.php";?>
    </header>
	<footer>
    	<?php include "footer.php";?>
    </footer>
</body>
</html>
