<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,intial-scale=1,maximum-scale=1">
        <title>MarketMate ADMIN</title>
		<link rel="stylesheet" type="text/css" href="./css/common.css">
		<link rel="stylesheet" type="text/css" href="./css/admin.css">
        <link rel="stylesheet" href="Admin_style.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    </head>
    <body>
        <input type="checkbox" id="nav-toggle">
        <div class="sidebar">
            <div class="sidebar-brand">
                <h1><span class="fa-solid fa-bowl-food"></span><span>MarketMate</span></h1>
            </div>
            <div class="sidebar-menu">
                <ul>
                    <li>
                        <a href="customer_information.php" class="active"><span class="las la-users"></span><span>고객 정보</span></a>
                    </li>
                    <li>
                        <a href="product_manage.php"><span class="las la-clipboard-list"></span><span>상품 관리</span></a>
                    </li>
                    <li>
                        <a href="product_register.php"><span class="las la-shopping-bag"></span><span>상품 등록</span></a>
                    </li>
                    <li>
                        <a href="order_list.php"><span class="las la-clipboard-list"></span><span>주문 리스트</span></a>
                    </li>
                    <li>
                        <a href="ask.php"><span class="las la-receipt"></span>
                            <span>1:1 문의</span></a>
                    </li>
               <br> <br> <br> <br> <br> <br> <br> <br>
            <?php
               session_start();
               if (isset($_SESSION["id"])) $id = $_SESSION["id"];
               else $id = "";
               if (isset($_SESSION["name"])) $name = $_SESSION["name"];
               else $name = "";
               $logged = $name."(".$id.")";
            ?>   
            <div id="logout_form">
               <form  name="logout_form" method="post" action="logout.php">
               <a href="logout.php"> &nbsp &nbsp &nbsp &nbsp <?=$logged?> &nbsp 로그아웃 </a>
            </div>
            </ul>
         </div>
        </div>
        <div class="main-content">
            <header>
                <h2>
                    <label for="nav-toggle">
                        <span class="las la-bars"></span>
                    </label>
                    고객정보
                </h2>
                <div class="search-wrapper">
                    <span class="las la-search"></span>
                    <input type="search" placeholder="Search here"/>
                </div>
            </header>
				<?php
					$con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");

					if (!$con) {
						die("Connection failed: " . mysqli_connect_error());
					}

					$sql = "SELECT COUNT(*) as total FROM client";

					$result = mysqli_query($con, $sql);

					if ($result) {
						$row = mysqli_fetch_assoc($result);
						$totalCustomers = $row['total'];
					} else {
						$totalCustomers = "Error: Unable to fetch data";
					}

					mysqli_close($con);
				?>
            <main>
                <div class="cards">
                    <div class="card-single">
                        <div>
                            <h1><?php echo $totalCustomers; ?></h1>
                            <span>고객 수</span>
                        </div>
                        <div>
                            <span class="las la-users"></span>
                        </div>
                    </div>
                </div>
                <div class="recent-grid">
                    <div class="projects">
                        <div class="card">
                            <div class="card-header">
                                <h3>고객 정보</h3>
                            </div>
                              <ul id="member_list">
                                 <li>
                                    <span class="col1">번호</span>
                                    <span class="col2">아이디</span>
                                    <span class="col3">이름</span>
                                    <span class="col4"> &nbsp &nbsp &nbsp &nbsp &nbsp 이메일</span>
                                    <span class="col5"></span>
                                    <span class="col6">전화번호</span>
                                    <span class="col7">가입일</span>
                                    <span class="col8">수정</span>
                                    <span class="col9">삭제</span>
                                 </li>
                                 <?php
                                    $con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");
                                    $sql = "select * from client order by num";
                                    $result = mysqli_query($con, $sql);
                                    $total_record = mysqli_num_rows($result); // 전체 회원 수

                                    $number = $total_record;

                                    while ($row = mysqli_fetch_array($result))
                                    {
                                      $num         = $row["num"];
                                      $id          = $row["id"];
                                      $name        = $row["name"];
                                      $email      = $row["email"];
                                      $tel         = $row["tel"];
                                      $regist_day  = $row["regist_day"];
                                 ?>
                                    
                                    <li>
                                       <form method="post" action="ClientmodifyForm.php?num=<?=$num?>">
                                          <span class="col1"><?=$num?></span>
                                          <span class="col2"><?=$id?></a></span>
                                          <span class="col3"><?=$name?></span>
                                          <span class="col4"><?=$email?></span>
                                          <span class="col5"></span>
                                          <span class="col6"><?=$tel?></span>
                                          <span class="col7"><?=$regist_day?></span>
                                          <span class="col8"><button type="submit">수정</button></span>
                                          <span class="col9"><button onclick="location.href='admin_member_delete.php?num=<?=$num?>'">삭제</button></span>
                                       </form>
                                    </li>
                                          
                                 <?php
                                       $number--;
                                    }
                                 ?>
                                </ul>
                                    </table>
                                </div>   
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </body>
</html>