<!DOCTYPE html>
<html>
<head> 
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>로그인</title>
	<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/53a8c415f1.js" crossorigin="anonymous"></script>
	<link href="css/style.css" rel="stylesheet">

	<script type="text/javascript" src="js/login.js"></script>
</head>
<body> 
	<section>
		<div class="wrap">
        <div class="login">
		    <a href="index.html"><h2> MarketMate </h2></a>
            <div class="login_sns">
            <li><a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a></li>
            <li><a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="https://twitter.com/"><i class="fab fa-twitter"></i></a></li>
            </div>
			<div id="login_form">
				<form  name="login_form" method="post" action="login.php">
				<div class="login_id">
					<input type="text" name="id" id="" placeholder="아이디">
				</div>
				<div class="login_pw">
					<input type="password" name="passwd" id="passwd" placeholder="비밀번호">
				</div>
				<div class="login_etc">
					<div class="checkbox">
					<input type="checkbox" name="" id=""> 자동로그인
					</div>
					<div class="forgot_pw">
						<a href="">비밀번호 찾기</a>
					</div>
				</div>
			</div>
            <div class="button">
                <input type="button" value="로그인" onclick="check_input()"> 
                <div class="small_text">아직 계정이 없으신가요? <a href="ClientForm.php">회원가입하기</a></div>
            </div>
			</form>
        </div>
    </div>
	</section> 
</body>
</html>

