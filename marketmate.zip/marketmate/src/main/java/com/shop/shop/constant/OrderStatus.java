package com.shop.shop.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
