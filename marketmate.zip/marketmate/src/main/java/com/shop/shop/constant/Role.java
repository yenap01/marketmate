package com.shop.shop.constant;

public enum Role {
    USER, ADMIN
}
