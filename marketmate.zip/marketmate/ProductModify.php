<?php

	$Item_Id = $_POST["Item_Id"];

    $Item_Type 	= $_POST["Item_Type"];
    $Item_Name 	= $_POST["Item_Name"];
    $Item_Type  = $_POST["Item_Type"];
    $Item_Price = $_POST["Item_Price"];
    $Item_stock = $_POST["Item_stock"];
          
    $con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");
    $sql = "update product set Item_Type='$Item_Type', Item_Name='$Item_Name', Item_Type='$Item_Type', Item_Price='$Item_Price', Item_stock='$Item_stock'";
    $sql .= " where Item_Id='$Item_Id'";
    mysqli_query($con, $sql);

    mysqli_close($con);     

    echo "
	      <script>
	          location.href = 'index.html';
	      </script>
	  ";
?>

   
