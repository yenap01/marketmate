<meta charset="utf-8">
<?php
    session_start();
    if (isset($_SESSION["id"])) $id = $_SESSION["id"];
    else $id = "";

    if (!$id )
    {
        echo("
                <script>
                alert('문의하기는 로그인 후 이용해 주세요!');
                history.go(-1)
                </script>
        ");
            exit;
    }

    $subject = $_POST["subject"];
    $content = $_POST["content"];
	
	$subject = htmlspecialchars($subject, ENT_QUOTES);
	$content = htmlspecialchars($content, ENT_QUOTES);
	
	$regist_day = date("Y-m-d (H:i)");  // 현재의 '년-월-일-시-분'을 저장
            
    $con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");

    $sql = "insert into enquire(id, subject, content, regist_day, hit) ";
    $sql .= "values('$id', '$subject', '$content', '$regist_day', 0)";

    mysqli_query($con, $sql);  // $sql 에 저장된 명령 실행
    mysqli_close($con);     

    echo "
	      <script>
	          location.href = 'ask.php';
	      </script>
	     ";
?>