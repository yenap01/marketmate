/*고객정보 페이지에서 고객 수를 계산하는 함수*/
function updateCustomerCount() {
    var customerCount = document.querySelectorAll('.table-responsive tbody tr').length;
    document.getElementById('customer-count').textContent = customerCount;
}

// 페이지가 로드될 때 한 번 호출하여 초기값을 설정
window.onload = function() {
    updateCustomerCount();
};


/*상품등록에서 종류 라디오버튼 선택시 옵션창 나옴*/
document.addEventListener('DOMContentLoaded', function() {
    var foodCategory = document.getElementById('foodCategory');
    var drinkCategory = document.getElementById('dailyCategory');
    
    document.querySelectorAll('input[name="category"]').forEach(function(radio) {
        radio.addEventListener('change', function() {
            if (this.value === 'food') {
                foodCategory.style.display = 'block';
                drinkCategory.style.display = 'none';
            } else if (this.value === 'daily') {
                foodCategory.style.display = 'none';
                drinkCategory.style.display = 'block';
            }
        });
    });
});

/*상품관리에서 수정,삭제 */
function editProduct(productCode) {
    var newProductName = prompt("새로운 상품명을 입력하세요:");
    var newCategory = prompt("새로운 종류를 입력하세요:");
    var newPrice = prompt("새로운 가격을 입력하세요:");
    var newStock = prompt("새로운 재고량을 입력하세요:");

    if (newProductName && newCategory && newPrice && newStock) {
        // TODO: 상품을 수정하는 로직을 여기에 추가하세요.
        alert("상품이 수정되었습니다:\n" +
              "상품코드: " + productCode + "\n" +
              "상품명: " + newProductName + "\n" +
              "종류: " + newCategory + "\n" +
              "가격: " + newPrice + "\n" +
              "재고현황: " + newStock);
    }

}

function deleteProduct(productCode) {
    var confirmDelete = confirm("정말로 삭제하시겠습니까?");

    if (confirmDelete) {
        // TODO: 상품을 삭제하는 로직을 여기에 추가하세요.
        alert("상품이 삭제되었습니다:\n" +
              "상품코드: " + productCode);
    }
}


