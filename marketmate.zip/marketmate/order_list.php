<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,intial-scale=1,maximum-scale=1">
        <title>MarketMate ADMIN</title>
		<link rel="stylesheet" type="text/css" href="./css/common.css">
		<link rel="stylesheet" type="text/css" href="./css/admin.css">
        <link rel="stylesheet" href="Admin_style.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    </head>
    <body>
        <input type="checkbox" id="nav-toggle">
        <div class="sidebar">
            <div class="sidebar-brand">
                <h1><span class="fa-solid fa-bowl-food"></span><span>MarketMate</span></h1>
            </div>
            <div class="sidebar-menu">
                <ul>
                    <li>
                        <a href="customer_information.php"><span class="las la-users"></span><span>고객정보</span></a>
                    </li>
                    <li>
                        <a href="product_manage.php"><span class="las la-clipboard-list"></span><span>상품 관리</span></a>
                    </li>
                    <li>
                        <a href="product_register.php"><span class="las la-shopping-bag"></span><span>상품 등록 </span></a>
                    </li>
                    <li>
                        <a href="order_list.php" class="active"><span class="las la-clipboard-list"></span><span>주문 리스트</span></a>
                    </li>
                    <li>
                        <a href="ask.php"><span class="las la-receipt"></span>
                            <span>1:1 문의</span></a>
                    </li>
                   <br> <br> <br> <br> <br> <br> <br> <br>
                <?php
                   session_start();
                   if (isset($_SESSION["id"])) $id = $_SESSION["id"];
                   else $id = "";
                   if (isset($_SESSION["name"])) $name = $_SESSION["name"];
                   else $name = "";
                   $logged = $name."(".$id.")";
                ?>
                <div id="logout_form">
                   <form  name="logout_form" method="post" action="logout.php">
                   <a href="logout.php"> &nbsp &nbsp &nbsp &nbsp <?=$logged?> &nbsp 로그아웃 </a>
                </div>
                </ul>
             </div>
        </div>
        <div class="main-content">
            <header>
                <h2>
                    <label for="nav-toggle">
                        <span class="las la-bars"></span>
                    </label>
                    
                </h2>
                <div class="search-wrapper">
                    <span class="las la-search"></span>
                    <input type="search" placeholder="Search here"/>
                </div>
            </header>
            <main>
                <div class="cards">
                    <div class="card-single">
                        <div>
                            <h1>3</h1>
                            <span>주문수</span>
                        </div>
                        <div>
                            <span class="las la-shopping-bag"></span>
                        </div>
                    </div>
                </div>
                <div class="recent-grid">
                    <div class="projects">
                        <div class="card">
                            <div class="card-header">
                                <h3>주문 리스트</h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table width="100%">
                                        <thead>
                                            <tr>
                                                <td>주문자ID</td>
                                                <td>상품코드</td>
                                                <td>상품명</td>
                                                <td>상품가격</td>
                                                <td>구매수량</td>
                                                <td>구매일자</td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>202031013</td>
                                                <td>10001</td>
                                                <td>사과</td>
                                                <td>6800원</td>
                                                <td>4</td>
                                                <td>2023.10.09  &nbsp오전 10:30:05</td>
                                            </tr>
                                            <tr>
                                                <td>202031026</td>
                                                <td>10002</td>
                                                <td>배</td>
                                                <td>8500원</td>
                                                <td>5</td>
                                                <td>2023.10.09  &nbsp오전 10:33:53</td>
                                            </tr>
                                            <tr>
                                                <td>202149028</td>
                                                <td>30001</td>
                                                <td>동원 고추참치</td>
                                                <td>3000원</td>
                                                <td>2</td>
                                                <td>2023.10.09  &nbsp오전 10:47:08</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </body>
</html>