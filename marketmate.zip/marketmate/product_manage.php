<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,intial-scale=1,maximum-scale=1">
        <title>MarketMate ADMIN</title>
		<link rel="stylesheet" type="text/css" href="./css/common.css">
		<link rel="stylesheet" type="text/css" href="./css/admin.css">
        <link rel="stylesheet" href="Admin_style.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    </head>
    <body>
        <input type="checkbox" id="nav-toggle">
        <div class="sidebar">
            <div class="sidebar-brand">
                <h1><span class="fa-solid fa-bowl-food"></span><span>MarketMate</span></h1>
            </div>
            <div class="sidebar-menu">
                <ul>
                    <li>
                        <a href="customer_information.php"><span class="las la-users"></span><span>고객정보</span></a>
                    </li>
                    <li>
                        <a href="product_manage.php" class="active"><span class="las la-clipboard-list"></span><span>상품 관리</span></a>
                    </li>
                    <li>
                        <a href="product_register.php"><span class="las la-shopping-bag"></span><span>상품 등록 </span></a>
                    </li>
                    <li>
                        <a href="order_list.php"><span class="las la-clipboard-list"></span><span>주문 리스트</span></a>
                    </li>
                    <li>
                        <a href="ask.php"><span class="las la-receipt"></span>
                            <span>1:1 문의</span></a>
                    </li>
                   <br> <br> <br> <br> <br> <br> <br> <br>
                <?php
                   session_start();
                   if (isset($_SESSION["id"])) $id = $_SESSION["id"];
                   else $id = "";
                   if (isset($_SESSION["name"])) $name = $_SESSION["name"];
                   else $name = "";
                   $logged = $name."(".$id.")";
                ?>
                <div id="logout_form">
                   <form  name="logout_form" method="post" action="logout.php">
                   <a href="logout.php"> &nbsp &nbsp &nbsp &nbsp <?=$logged?> &nbsp 로그아웃 </a>
                </div>
                </ul>
             </div>
        </div>
        <div class="main-content">
            <header>
                <h2>
                    <label for="nav-toggle">
                        <span class="las la-bars"></span>
                    </label>
                    상품 관리
                </h2>
                <div class="search-wrapper">
                    <span class="las la-search"></span>
                    <input type="search" placeholder="Search here"/>
                </div>
            </header>
        <main>
            <div class="cards">
                <div class="card-single">
                    <div>
                        <h1>3</h1>
                        <span>상품 수</span>
                    </div>
                    <div>
                        <span class="las la-clipboard"></span>
                    </div>
                </div>
            </div>
            <div class="recent-grid">
                <div class="projects">
                    <div class="card">
                        <div class="card-header">
                            <h3>상품관리</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table width="100%" id="product-table">
                                    <thead>
                                        <tr>
                                            <td>상품코드</td>
                                            <td>상품명</td>
                                            <td>종류</td>
                                            <td>가격</td>
                                            <td>재고현황</td>
                                            <td></td>
                                        </tr>
                                    </thead>
                                    <tbody id="product-table-body">
                                        <tr>
                                            <td id="product-code-10001">10001</td>
                                            <td id="product-name-10001" onclick="enableEdit('product-name-10001')">사과</td>
                                            <td>과일/채소</td>
                                            <td>1700원</td>
                                            <td id="product-stock-10001" onclick="enableEdit('product-stock-10001')">500</td>
                                            <td>
                                                <button class="edit-button" onclick="editProduct(10001)">수정<span class="las la-arrow-right"></span></button>
                                                <button class="delete-button" onclick="deleteProduct(10001)">삭제<span class="las la-arrow-right"></span></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td id="product-code-30001">30001</td>
                                            <td id="product-name-30001" onclick="enableEdit('product-name-30001')">동원 고추참치</td>
                                            <td>면/통조림</td>
                                            <td>1500원</td>
                                            <td id="product-stock-30001" onclick="enableEdit('product-stock-30001')">200</td>
                                            <td>
                                                <button class="edit-button" onclick="editProduct(30001)">수정<span class="las la-arrow-right"></span></button>
                                                <button class="delete-button" onclick="deleteProduct(30001)">삭제<span class="las la-arrow-right"></span></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td id="product-code-10002">10002</td>
                                            <td id="product-name-10002" onclick="enableEdit('product-name-10002')">배</td>
                                            <td>과일/채소</td>
                                            <td>1700원</td>
                                            <td id="product-stock-10002" onclick="enableEdit('product-stock-10002')">460</td>
                                            <td>
                                                <button class="edit-button" onclick="editProduct(10002)">수정<span class="las la-arrow-right"></span></button>
                                                <button class="delete-button" onclick="deleteProduct(10002)">삭제<span class="las la-arrow-right"></span></button>
                                            </td>
                                        </tr>
                                        <!-- 다른 상품들도 동일한 형식으로 추가 -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        </div>
        <script src="script.js"></script>
    </body>
</html>