<?php
    $num  = $_POST["num"];
    $Order_Id = $_POST["Order_Id"];
    $OItem_Id = $_POST["OItem_Id"];
    $OItem_Name  = $_POST["OItem_Name"];
    $OItem_Type  = $_POST["OItem_Type"];
	$OItem_Price  = $_POST["OItem_Price"];
	$OItem_Stock  = $_POST["OItem_Stock"];
	$Oregist_day  = $_POST["regist_day"];

    echo "num => $num<br>";
    echo "Order_Id => $Order_Id<br>";
    echo "OItem_Id => $OItem_Id<br>";
	echo "OItem_Type => $OItem_Type<br>";
    echo "OItem_Name => $OItem_Name<br>";
	echo "OItem_Price => $OItem_Price<br>";
	echo "OItem_Stock => $OItem_Stock<br>";
	echo "regist_day => $Oregist_day<br>";

//*              
    $con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");

    $sql = "insert into client(num, Order_Id, OItem_Id, OItem_Name, OItem_Type, OItem_Price, OItem_Stock, regist_day) ";
    $sql .= "values('$num', '$Order_Id', '$OItem_Id', '$OItem_Name', '$OItem_Type', '$OItem_Price', '$OItem_Stock', '$regist_day')";

    mysqli_query($con, $sql);  // $sql 에 저장된 명령 실행
    mysqli_close($con);     

    echo "
	      <script>
	          location.href = 'index.html';
	      </script>
	  ";
/**/
?>