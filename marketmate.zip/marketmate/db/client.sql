create table client (
    num int not null auto_increment,
    id varchar(15) not null,
    passwd varchar(15) not null,
    name varchar(10) not null,
    email varchar(80) not null,
	tel varchar(20) not null,
    regist_day varchar(20) not null,
    level int,
    primary key(num)
);

