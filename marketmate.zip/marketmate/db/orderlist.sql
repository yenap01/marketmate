create table orderlist (
    num int not null auto_increment,
    Order_Id varchar(15) not null,
    OItem_Id varchar(10) not null,
    OItem_Type varchar(10) not null,
    OItem_Name varchar(80) not null,
	OItem_Price varchar(10) not null,
	OItem_stock varchar(80) not null,
	regist_day varchar(20) not null,
    primary key(num)
);

