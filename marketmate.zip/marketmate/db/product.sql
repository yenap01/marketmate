create table product (
    Item_Num varchar(10) not null auto_increment,
    Item_Name varchar(15) not null,
    Item_Type varchar(10) not null,
    Item_Price varchar(10) not null,
    Item_Stock varchar(80) not null,
	file_name char(40),
	file_type char(40),
	file_copied char(40),
    primary key(num)
);

