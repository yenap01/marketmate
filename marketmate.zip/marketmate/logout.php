<?php
  session_start();
  unset($_SESSION["id"]);
  unset($_SESSION["name"]);
  
  echo("
       <script>
          location.href = 'login_form.php';
         </script>
       ");
?>
