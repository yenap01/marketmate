<?php
    $num   = $_GET["num"];
    $page   = $_GET["page"];

	$con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");
    $sql = "select * from enquire where num = $num";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($result);

    $sql = "delete from enquire where num = $num";
    mysqli_query($con, $sql);
    mysqli_close($con);

    echo "
	     <script>
	         location.href = 'contact_list.php?page=$page';
	     </script>
	   ";
?>

