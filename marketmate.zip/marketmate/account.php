<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>MarketMate</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500&family=Roboto:wght@500;700;900&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="./css/common.css">
    <link rel="stylesheet" type="text/css" href="./css/member.css">
    <script type="text/javascript" src="./js/ClientModify.js"></script>
</head>

<body>
    <header>
        <?php
               session_start();
               if (isset($_SESSION["id"])) $id = $_SESSION["id"];
               else $id = "";
               $logged = $id;
        ?>
    </header>

    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">계정 수정</h1>
        </div>
    </div>
    <!-- Page Header End -->

<?php
   	$con = mysqli_connect("localhost", "sjy3739", "a202031013", "sjy3739");
    $sql    = "select * from client where id='$id'";
    $result = mysqli_query($con, $sql);
    $row    = mysqli_fetch_array($result);

    $passwd = $row["passwd"];
    $name = $row["name"];
    $email = explode("@", $row["email"]);
    $email1 = $email[0];
    $email2 = $email[1];
	$tel = $row["tel"];

    mysqli_close($con);
?>
	<section>
        <div id="main_content">
      		<div id="join_box">
          	<form name="ClientForm" method="post" action="Client_Modify.php">
          	<input type="hidden" name="id" id="id" value="<?=id?>">
    		    	<div class="form id">
				        <div class="col1">아이디</div>
				        <div class="col2">
				            <?=$id?>
				        </div>
			       	</div>
			       	<div class="clear"></div>
			       	<div class="form">
				        <div class="col1">비밀번호</div>
				        <div class="col2">
							<input type="password" name="passwd" value="<?=$passwd?>">
				        </div>                 
			       	</div>
			       	<div class="clear"></div>
			       	<div class="form">
				        <div class="col1">비밀번호 확인</div>
				        <div class="col2">
							<input type="password" name="passwd_confirm" value="<?=$passwd?>">
				        </div>                 
			       	</div>
			       	<div class="clear"></div>
			       	<div class="form">
				        <div class="col1">이름</div>
				        <div class="col2">
							<input type="text" name="name" value="<?=$name?>">
				        </div>                 
			       	</div>
					<div class="clear"></div>
			       	<div class="form email">
				        <div class="col1">이메일</div>
				        <div class="col2">
							<input type="text" name="email1" value="<?=$email1?>">@
							<input type="text" name="email2" value="<?=$email2?>">
				        </div>                 
			       	</div>
					<div class="clear"></div>
			       	<div class="form">
				        <div class="col1">휴대폰 번호</div>
				        <div class="col2">
							<input type="text" name="tel" value="<?=$tel?>">
				        </div>                 
			       	</div>
			       	<div class="clear"></div>
			       	<div class="bottom_line"> </div>
			       	<div class="buttons">
	                	<img style="cursor:pointer" src="./img/button_save.gif" onclick="check_input()">&nbsp;
                  		<img id="reset_button" style="cursor:pointer" src="./img/button_reset.gif"
                  			onclick="reset_form()">
	           		</div>
           	</form>
        	</div> <!-- join_box -->
        </div> <!-- main_content -->
	</section> 
	<footer>
    	<?php include "footer.php";?>
    </footer>
</body>
</html>

