﻿<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <title>MarketMate</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500&family=Roboto:wght@500;700;900&display=swap" rel="stylesheet">

        <!-- Icon Font Stylesheet -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
        <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">

            <script>
                // 로그인 상태를 확인하는 변수 (예: 사용자가 로그인 중인지 여부)
                let isLoggedIn = false; // 이 변수를 실제 상태에 따라 설정하세요.

                // 로그인 버튼 엘리먼트를 가져오기
                const loginButton = document.querySelector(".btn.btn-primary");

                // 로그인 상태에 따라 버튼 텍스트 업데이트
                function updateLoginButton() {
                    if (isLoggedIn) {
                        loginButton.innerText = "로그아웃";
                    } else {
                        loginButton.innerText = "로그인";
                    }
                }

                // "로그인" 버튼 클릭 이벤트 처리
                loginButton.addEventListener("click", () => {
                    if (isLoggedIn) {
                        // 로그아웃 로직을 여기에 추가
                        // 예: 사용자 로그아웃 처리 및 변수 업데이트
                        isLoggedIn = false;
                    } else {
                        // 로그인 로직을 여기에 추가
                        // 예: 사용자 로그인 처리 및 변수 업데이트
                        isLoggedIn = true;
                    }

                    // 버튼 텍스트 업데이트
                    updateLoginButton();
                });

                // 초기 상태에서 버튼 텍스트 설정
                updateLoginButton();
            </script>
</head>

<body>
<!-- Topbar Start -->
<div class="container-fluid bg-light p-0">
    <div class="row gx-0 d-none d-lg-flex">
        <div class="col-lg-7 px-5 text-start">
            <div class="h-100 d-inline-flex align-items-center py-3 me-4">
                <small class="fa fa-map-marker-alt text-primary me-2"></small>
                <small>경복궁점</small>
            </div>
            <div class="h-100 d-inline-flex align-items-center py-3">
                <small class="far fa-clock text-primary me-2"></small>
                <small>Mon - Sat : 10.00 AM - 09.00 PM</small>
            </div>
        </div>
        <div class="col-lg-5 px-5 text-end">
            <div class="h-100 d-inline-flex align-items-center py-3 me-4">
                <small class="fa fa-phone-alt text-primary me-2"></small>
                <small>031 - 1234 - 5678</small>
            </div>
        </div>
    </div>
</div>
<!-- Topbar End -->

<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
    <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <h2 class="m-0 text-primary">MarketMate</h2>
    </a>
    <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-5 p-lg-0">
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto p-5 p-lg-0">
                    <a href="index.html" class="nav-item nav-link ">홈</a>
                    <a href="category.html" class="nav-item nav-link ">카테고리</a>
                    <a href="sale.html" class="nav-item nav-link ">세일</a>
                    <a href="event.html" class="nav-item nav-link ">이벤트</a>
                    <a href="mypage.php" class="nav-item nav-link ">마이페이지</a>
                    <a href="shoppingbasket.html" class="nav-item nav-link ">장바구니</a>
                    <a href="contact.php" class="nav-item nav-link ">문의하기</a>
            <div class="nav-item dropdown">
             <!--<a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Mypage</a>
                <div class="dropdown-menu fade-up m-0">
                    <a href="history.html" class="dropdown-item">결제내역</a>
                    <a href="Recently.html" class="dropdown-item">최근본상품</a>
                    <a href="information.html" class="dropdown-item">정보관리</a>
                </div>-->



<?php
    if(isset($_SESSION["id"])) {
        $id = $_SESSION["id"];
?>
<a href="logout.php" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block">로그 아웃 </a>
<?php
    } else {
        $id = "";
?>
 <a href="login.html" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block">로그인 </a>
<?php
    }
?>

    </div>
</nav>
<!-- Navbar End -->
<!-- Back to Top -->
<a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-0 back-to-top"><i class="bi bi-arrow-up"></i></a>


<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>
<script src="lib/counterup/counterup.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/isotope/isotope.pkgd.min.js"></script>
<script src="lib/lightbox/js/lightbox.min.js"></script>

<!-- Template Javascript -->
<script src="js/main.js"></script>
</body>

</html>